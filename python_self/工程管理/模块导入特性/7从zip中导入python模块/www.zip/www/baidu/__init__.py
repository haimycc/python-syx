print("this is baidu")
baidu="baidu"