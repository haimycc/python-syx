print("this is www")
www="www"