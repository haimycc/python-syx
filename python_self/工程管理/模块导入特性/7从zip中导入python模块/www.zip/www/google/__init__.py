print("this is google")
google="google"